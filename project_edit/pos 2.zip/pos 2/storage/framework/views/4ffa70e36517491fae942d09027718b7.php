<!DOCTYPE html>
<html>

<head>
    <title>pdf</title>
    <meta http-equiv="Content-Language" content="th" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link
        href="https://fonts.googleapis.com/css2?family=Sarabun:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap"
        rel="stylesheet">
    <style>
        body {
            font-family: 'sarabun', sans-serif;
        }

        table {
            width: 100%;
        }

        .box {
            border: 1px dashed black;
            padding: -10px;
        }
        img{
            margin-top: 4px;
        }

    </style>
</head>

<body>
    <h3>รหัสสินค้า : <?php echo e($product['code']); ?> / ชื่อสินค้า : <?php echo e($product['product_name']); ?></h3>
    <?php
        $generatorPNG = new Picqer\Barcode\BarcodeGeneratorPNG();
    ?>
    <table>
        <?php for($i =0; $i< $count_row;$i++): ?>
        <tr>
            
            <td class="box">
                <center>
                    <div>
                        <span><?php echo e($product['product_name']); ?></span><br>
                        <img
                            src="data:image/png;base64,<?php echo e(base64_encode($generatorPNG->getBarcode($product['code'], $generatorPNG::TYPE_CODE_128))); ?>">
                        <span style="display:block; margin-top:-5px;">code</span>
                        <p style="margin-top:-7px;"><?php echo e($product['product_price']); ?> บาท</p>
                    </div>
                </center>
            </td>
            <td class="box">
                <center>
                    <div>

                        <span><?php echo e($product['product_name']); ?></span><br>
                        <img
                            src="data:image/png;base64,<?php echo e(base64_encode($generatorPNG->getBarcode($product['code'], $generatorPNG::TYPE_CODE_128))); ?>">
                        <span style="display:block; margin-top:-5px;">code</span>
                        <p style="margin-top:-2px;"><?php echo e($product['product_price']); ?> บาท</p>

                    </div>
                </center>
            </td>
            <td class="box">
                <center>
                    <div>

                        <span><?php echo e($product['product_name']); ?></span><br>
                        <img
                            src="data:image/png;base64,<?php echo e(base64_encode($generatorPNG->getBarcode($product['code'], $generatorPNG::TYPE_CODE_128))); ?>">
                        <span style="display:block; margin-top:-5px;">code</span>
                        <p style="margin-top:-2px;"><?php echo e($product['product_price']); ?> บาท</p>
                    </div>
                </center>
            </td>
        </tr>
        <?php endfor; ?>
    </table>

</body>

</html>
<?php /**PATH /Applications/MAMP/htdocs/sale-course/resources/views/pages/barcode.blade.php ENDPATH**/ ?>