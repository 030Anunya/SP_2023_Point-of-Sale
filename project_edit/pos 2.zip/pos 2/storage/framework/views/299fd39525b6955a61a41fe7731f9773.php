<!-- Modal -->
<div class="modal fade" id="modalsubcategory" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">
                    เพิ่มหมวดหมู่ใหม่</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="form-horizontal" id="subcategoryForm-create" action="<?php echo e(route('subcategory.store')); ?>"
                method="POST">
                <div class="modal-body">
                    <div id="create-category">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="fname" class="col-sm-3 text-end control-label col-form-label">
                                ชื่อหมวดหมู่</label>
                            <div class="col-sm-9">
                                <select class="form-select" name="selct_category" id="selct_category" required>
                                    <option value="" disabled selected>เลือกหมวดหมู่</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>">
                                            <?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname" class="col-sm-3 text-end control-label col-form-label">
                                ชื่อหมวดหมู่</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="sub_category_name"
                                    name="sub_category_name" placeholder="โปรดระบุหมวดหมู่สินค้า" required />
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                    <button type="submit" class="btn btn-primary " id="saveCategory">บันทึก</button>
                </div>
            </form>
            <form class="form-horizontal d-none" id="subcategoryForm-update"
                action="<?php echo e(route('subcategory.update', 45)); ?>" method="POST">
                <div class="modal-body">
                    <div id="create-category">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group row">
                            <label for="fname" class="col-sm-3 text-end control-label col-form-label">
                                ชื่อหมวดหมู่</label>
                            <div class="col-sm-9">
                                <select class="form-select" name="selct_category_sub" id="selct_category_sub" required>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>">
                                            <?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname" class="col-sm-3 text-end control-label col-form-label">
                                ชื่อหมวดหมู่แก้ไข</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="sub_category_name_edit"
                                    name="sub_category_name_edit" placeholder="โปรดระบุหมวดหมู่สินค้า" required />
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                    <button type="submit" class="btn btn-primary " id="saveCategory">บันทึก</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/sale-course/resources/views/components/modalSubCategory.blade.php ENDPATH**/ ?>