<?php $__env->startSection('bread'); ?>
    <div class="col-12 d-flex no-block align-items-center">
        <h4 class="page-title">รายการขาย</h4>
        <div class="ms-auto text-end">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">หน้าหลัก</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        รายการขาย
                    </li>
                </ol>
            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>รหัส</th>
                                    <th>พนักงานขาย</th>
                                    <th>วันที่ขาย</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $listSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  
                                <tr>
                                        <td><?php echo e($listSale->order_code); ?></td>
                                        <td><?php echo e($listSale->users->first_name); ?> <?php echo e($listSale->users->last_name); ?>  </td>
                                        <td><?php echo e(date_format($listSale->created_at, 'd/m/Y H:i')); ?></td>
                                        <td><a href="<?php echo e(url('historysale/detail',$listSale->id)); ?>" class="btn btn-outline-info">รายละเอียด</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/pos 2/resources/views/pages/listsale/historySale.blade.php ENDPATH**/ ?>