<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">
                    เพิ่มสินค้าใหม่</h1>
                <button type="button" class="btn-close" onclick="closeModal()" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form id="productForm" class="form-horizontal" method="post" action="<?php echo e(url('/products')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id_product" id="id_product">
                    <h4 class="card-title">รายละเอียดสินค้า</h4>
                    <div class="form-group row">
                        <label for="fname" class="col-sm-3 text-end control-label col-form-label">
                            ภาพสินค้า</label>
                        <div class="col-sm-9">
                            <div class="d-flex justify-content-center">
                                <img id="blah" src="#" alt="your image" width="90" height="70"
                                    class="rounded mb-2 d-none" />
                            </div>
                            <input accept="image/*" name="image" type='file' id="imgInp" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="fname" class="col-sm-3 text-end control-label col-form-label">
                            ชื่อสินค้า</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="product_name" name="product_name"
                                placeholder="โปรดระบุชื่อสินค้า" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="lname" class="col-sm-3 text-end control-label col-form-label">
                            หมวดหมู่สินค้า*</label>
                        <div class="col-sm-9">
                            <select class="form-select" name="category" id="category"
                                onchange="findSubCategory(event)">
                                <option value="" disabled selected>เลือกหมวดหมู่</option>
                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>">
                                        <?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="lname" class="col-sm-3 text-end control-label col-form-label">
                            แบรนด์ / ยี่ห้อ*</label>
                        <div class="col-sm-9">
                            <select class="form-select" name="sub_category" id="sub_category">
                                <option value="" disabled selected>เลือกประเภท</option>
                                <div id="result_list_sub_category"></div>
                                
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email1" class="col-sm-3 text-end control-label col-form-label">วันหมดอายุ</label>
                        <div class="col-sm-9">
                            <input type="date" class="form-control" id="Expiry_Date" name="Expiry_Date"
                                placeholder="วันหมดอายุ" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email1" class="col-sm-3 text-end control-label col-form-label">รหัสสินค้า*</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="code" name="code"
                                placeholder="โปรดระบุรหัสสินค้า" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cono1" class="col-sm-3 text-end control-label col-form-label">คลังสินค้า</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="stock" name="stock"
                                placeholder="โปรดระบุจำนวนสินค้า" />
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cono1" class="col-sm-3 text-end control-label col-form-label">น้ำหนัก</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">กก</span>
                                </div>
                                <input type="text" name="weight" id="weight" class="form-control"
                                    placeholder="น้ำหนัก" aria-label="Username" aria-describedby="basic-addon1" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cono1"
                            class="col-sm-3 text-end control-label col-form-label">ต้นทุนราคาสินค้า</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">฿</span>
                                </div>
                                <input type="text" name="product_cost" id="product_cost" class="form-control"
                                    placeholder="โปรดระบุราคาต้นทุน" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cono1"
                            class="col-sm-3 text-end control-label col-form-label">ราคาขายสินค้า</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">฿</span>
                                </div>
                                <input type="text" name="product_price" id="product_price" class="form-control"
                                    placeholder="โปรดระบุราคาขาย" aria-label="Username"
                                    aria-describedby="basic-addon1" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cono1"
                            class="col-sm-3 text-end control-label col-form-label">รายละเอียดสินค้า</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="description" id="description"></textarea>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">ยกเลิก</button>
                <button type="submit" class="btn btn-primary" id="submit_btn">บันทึก</button>
            </div>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    imgInp.onchange = evt => {
        $('#blah').removeClass('d-none')
        const [file] = imgInp.files
        if (file) {
            blah.src = URL.createObjectURL(file)
        }
    }

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });


    function closeModal() {
        $('#id_product').val('');
        $('#blah').attr('src', '')
        $('#sub_category').html('<option value="" disabled selected>เลือกประเภท</option>')
        $('#staticBackdrop').modal('hide')
        document.getElementById('productForm').reset();
        $(".error-message").remove();
    }

    function findSubCategory(e) {

        $.ajax({
            url: '/subcategory/' + e.target.value,
            type: 'get',
            success: function(response) {
                let show_list = ''
                response.forEach(element => {
                    show_list += `<option value="${element.id}">${element.sub_category_name}</option>`
                });

                $('#sub_category').html(show_list)
            },
            error: function(xhr) {
                console.log(xhr);
            }
        });
    }
    $(document).ready(function() {
        $("#productForm").submit(function(event) {
            event.preventDefault();

            var formData = new FormData(this);
            var imageInput = $('input[name="image"]')[0];
            console.log(imageInput.files[0]);

            formData.append('image', imageInput.files[0]);

            $.ajax({
                url: $(this).attr("action"),
                type: $(this).attr("method"),
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    $('#submit_btn').attr('disabled', '')
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                            toast.addEventListener('mouseenter', Swal
                                .stopTimer);
                            toast.addEventListener('mouseleave', Swal
                                .resumeTimer);
                        }
                    });

                    Toast.fire({
                        icon: 'success',
                        title: "บันทึกสินค้าสำเร็จ"
                    });

                    setTimeout(() => {
                        location.reload()
                    }, 1200);

                },
                error: function(xhr) {

                    if (xhr.status === 422) {
                        var errors = xhr.responseJSON.errors;

                        $(".error-message").remove();

                        $.each(errors, function(field, errorMessages) {
                            var errorHtml =
                                '<div class="error-message text-danger">' +
                                errorMessages.join(', ') + '</div>';
                            $("#" + field).closest(".col-sm-9").append(errorHtml);
                        });
                    } else {
                        console.error("Form submission failed");
                    }
                }
            });
        });


    });


    function EditProduct(id) {
        $('#blah').removeClass('d-none')
        $('#id_product').val(id);
        $('#submit_btn').text('อัพเดต')
        $.ajax({
            url: '/products/' + id + '/edit',
            type: 'get',
            success: function(response) {
                $('#blah').attr('src', 'storage/uploads/' + response.product_img)
                $('#product_name').val(response.product_name)
                $('#product_price').val(response.product_price)
                $('#Expiry_Date').val(response.Expiry_Date)
                $('#code').val(response.code)
                $('#stock').val(response.stock)
                $('#description').val(response.description)
                $('#weight').val(response.weight)
                $('#product_cost').val(response.product_cost)
                $('#weight').val(response.weight)
                $('#category').val(response.category ? response.category.id : '')
                $('#sub_category').val(response.subcategory ? response.subcategory.id : '')
                $('#staticBackdrop').modal('show')
            },
            error: function(xhr) {
                console.log(xhr.status);
            }
        })
    }

    function openModal() {
        $('#submit_btn').text('บันทึก');
        $('#blah').addClass('d-none')
        $('#staticBackdrop').modal('show')
    }
</script>
<?php /**PATH /Applications/MAMP/htdocs/sale-course/resources/views/components/modalProduct.blade.php ENDPATH**/ ?>