<?php $__env->startSection('bread'); ?>
    <div class="col-12 d-flex no-block align-items-center">
        <h4 class="page-title">ยอดขายรายเดือน</h4>
        <div class="ms-auto text-end">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">หน้าหลัก</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        ยอดขายรายเดือน
                    </li>
                </ol>
            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php
                        $currentYear = date('Y');
                    ?>
                    <h1 class="text-center">ยอดขายประจำเดือน <?php echo e($yearShow); ?></h1>

                    <form action="<?php echo e(url('/historySaleMonth')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <select name="year" id="year" class="form-select">
                            <option value="" disabled selected>เลือกดูยอดการขาย</option>
                            <?php for($year = $currentYear; $year <= $currentYear + 1; $year++): ?>
                                <option value="<?php echo e($year); ?>"><?php echo e($year + 543); ?></option>
                            <?php endfor; ?>
                        </select>
                        <button type="submit" class="btn btn-success w-100 my-2 text-white">ค้นหา</button>
                    </form>
                    <canvas id="myChart"></canvas>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="zero_config" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ลำดับ</th>
                                            <th>เดือน</th>
                                            <th>ยอดขาย / บาท</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <?php for($i = 0; $i < count($labels); $i++): ?>
                                            <tr>
                                                <td><?php echo e($i + 1); ?></td>
                                                <td><?php echo e($labels[$i]); ?></td>
                                                <td><?php echo e($data[$i]); ?></td>
                                            </tr>
                                        <?php endfor; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        const ctx = document.getElementById('myChart');
        var labels = <?php echo json_encode($labels, 15, 512) ?>;
        console.log(labels);
        var data = <?php echo json_encode($data, 15, 512) ?>;
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'ยอดขายรายเดือน',
                    data: data,
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/pos 2/resources/views/pages/listsale/historySaleMonth.blade.php ENDPATH**/ ?>