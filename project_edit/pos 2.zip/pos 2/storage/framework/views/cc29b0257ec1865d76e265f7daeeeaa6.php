<html>
<header>
    <title>pdf</title>
    <meta http-equiv="Content-Language" content="th" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link
        href="https://fonts.googleapis.com/css2?family=Sarabun:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap"
        rel="stylesheet">
    <style>
        body {
            font-family: 'sarabun', sans-serif;
            font-size: 20px;
        }
    </style>
</header>

<body>

    <style>
        hr {}
    </style>
    <div>
        <table>
            <tbody>
                <tr>
                    <td colspan="2" style="text-align:center;"><img
                            src="https://img.freepik.com/free-vector/bird-colorful-logo-gradient-vector_343694-1365.jpg"
                            alt="7-Eleven" width="60"></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align:center;">
                        <h1>ใบเสร็จรับเงิน/รายการสินค้า</h1>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <hr style="border: 1px dashed black;">
                    </td>
                </tr>
                <tr>
                    <th>Qty</th>
                    <th style="text-align:start;">สินค้า</th>
                    <th>ราคา/หน่วย</th>
                    <th>ราคารวม</th>
                </tr>
                <tr>
                    <td style="text-align:center;">x </td>
                    <td></td>
                    <td>@</td>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="3">ส่วนลดจาก </td>
                    <td colspan="2"></td>
                </tr>

                <tr>
                    <td colspan="4">
                        <hr style="border: 1px dashed black;">
                    </td>
                </tr>
                <tr>
                    <td colspan="1"></td>
                    <td style="text-align:right;">รวมเป็นเงิน:</td>
                    <td colspan="2" style="text-align:right;">บาท</td>
                </tr>
                <tr>
                    <td colspan="1"></td>
                    <td style="text-align:right;">ภาษีมูลค่าเพิ่ม 7%:</td>
                    <td colspan="2" style="text-align:right;">
                        บาท</td>
                </tr>
                <tr>
                    <td colspan="1"></td>
                    <td style="text-align:right;">รวมทั้งสิ้น:</td>
                    <td colspan="2" style="text-align:right;">
                        บาท</td>
                </tr>
                <tr>
                    <td colspan="1"></td>
                    <td style="text-align:right;">วันที่:</td>
                    <td colspan="2" style="text-align:right;"></td>
                </tr>
            </tbody>
        </table>
</body>

</html>
<?php /**PATH /Applications/MAMP/htdocs/sale-course/resources/views/pdf.blade.php ENDPATH**/ ?>