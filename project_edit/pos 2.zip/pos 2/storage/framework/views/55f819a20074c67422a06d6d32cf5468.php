<?php $__env->startSection('bread'); ?>
    <div class="col-12 d-flex no-block align-items-center">
        <h4 class="page-title">รายการสินค้า</h4>
        <div class="ms-auto text-end">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">หน้าหลัก</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        รายการสินค้า
                    </li>
                </ol>
            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-end mb-4">

                        <div class="btn-group">
                            <button type="button" class="btn btn-success text-white" onclick="openModalExcel()">
                                นำสินค้าเข้า
                            </button>
                            <a href="<?php echo e(url('/generate-pdfProduct')); ?>" target="_blank" class="btn btn-secondary">
                                พิมพ์สต็อก <i class="fa-solid fa-print"></i>
                            </a>
                            <button type="button" class="btn btn-primary" onclick="openModal()">
                                เพิ่มสินค้า
                            </button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ลำดับ</th>
                                    <th>รูปภาพ</th>
                                    <th>ชื่อสินค้า</th>
                                    <th>หมวดหมู่</th>
                                    <th>สต๊อก/ชิ้น</th>
                                    <th>ราคา/บาท</th>
                                    <th>สถานะ</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        if ($product->Expiry_Date !== null) {
                                            $date1 = date('Y-m-d');
                                            $date2 = $product->Expiry_Date;
                                        
                                            $dateTime1 = new DateTime($date1);
                                            $dateTime2 = new DateTime($date2);
                                        
                                            $interval = $dateTime1->diff($dateTime2);
                                        
                                            $days = $interval->days;
                                        }
                                    ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><img class="img-fluid img-product" width="72" height="72"
                                                src="<?php echo e(asset($product->product_img !== null ? 'storage/uploads/' . $product->product_img : 'storage/uploads/no-product.jpeg')); ?>"
                                                alt="<?php echo e($product->product_name); ?>"></td>
                                        <td><?php echo e($product->product_name); ?></td>
                                        <td><?php echo e($product->category ? $product->category->category_name : 'สินค้านำเข้า'); ?>

                                        </td>

                                        <td>
                                            <span class="<?php echo e($product->stock == 0 ? 'text-danger' : 'text-success'); ?>">
                                                <?php echo e($product->stock == 0 ? 'สินค้าหมด' : number_format($product->stock)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e(number_format($product->product_price, 2)); ?></td>
                                        <td><?php
                                            if (!isset($days)) {
                                                echo '<span class="badge bg-success">ปกติ</span>';
                                            } elseif ($days > 7) {
                                                echo '<span class="badge bg-success">ปกติ</span>';
                                            } elseif ($days <= 7 && $days > 0) {
                                                echo '<span class="badge bg-warning">ใกล้หมดอายุ</span>';
                                            } else {
                                                echo '<span class="badge bg-danger">หมดอายุ</span>';
                                            }
                                        ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a class="btn btn-info" onclick="printBarcode(<?php echo e($product->id); ?>)"><i
                                                        class="fa-solid fa-barcode"></i></a>
                                                <button class="btn btn-warning"
                                                    onclick="EditProduct(<?php echo e($product->id); ?>)"><i
                                                        class="mdi mdi-pencil"></i></button>

                                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>"
                                                    method="post" class="form_delete_product">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="button" class="btn btn-danger" onclick="removeProduct(<?php echo e($product->id); ?>,'<?php echo e($product->product_name); ?>')">
                                                        <i class="mdi mdi-delete"></i>
                                                    </button>
                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('components.modalProduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.modalPrintBarcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.modalExcel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function openModalExcel() {
            $('file').val('')
            $('#modalExcel').modal('show')
        }

        function removeProduct(id, product) {
            $('.form_delete_product').attr('action', `<?php echo e(route('products.destroy', ['product' => ':id'])); ?>`
                .replace(
                    ':id', id))

            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
                title: `คุณต้องการลบ ${product}`,
                text: "",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'ตกลง',
                cancelButtonText: 'ยกเลิก',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    $('.form_delete_product').submit()
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'ยกเลิกแล้ว',
                        '',
                        'error'
                    )
                }
            })

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sale-course/resources/views/pages/product.blade.php ENDPATH**/ ?>