<?php $__env->startSection('bread'); ?>
    <div class="col-12 d-flex no-block align-items-center">
        <h4 class="page-title">หน้าหลัก</h4>
        <div class="ms-auto text-end">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">หน้าหลัก</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        สรุปผล
                    </li>
                </ol>
            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- Sales Cards  -->
    <!-- ============================================================== -->
    <?php if(Auth::user()->is_admin): ?>
        <div class="row">
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
                <div class="card card-hover">
                    <div class="box bg-cyan text-center">
                        <h1 class="font-light text-white">
                            <i class="mdi mdi-view-dashboard"></i>
                        </h1>
                        <h1></h1>
                        <h6 class="text-white">สินค้าในระบบ</h6>
                        <span class="text-white"><?php echo e(number_format($product_count)); ?> รายการ</span>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
                <div class="card card-hover">
                    <div class="box bg-success text-center">
                        <h1 class="font-light text-white">
                            <i class="mdi mdi-chart-areaspline"></i>
                        </h1>
                        <h6 class="text-white">พนักงานในระบบ</h6>
                        <span class="text-white"><?php echo e(number_format($coustomer_count)); ?> คน</span>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
                <div class="card card-hover">
                    <div class="box bg-warning text-center">
                        <h1 class="font-light text-white">
                            <i class="mdi mdi-collage"></i>
                        </h1>
                        <h6 class="text-white">รายการขายวันนี้</h6>
                        <span class="text-white"><?php echo e(number_format($listsale_count_day)); ?> รายการ</span>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-3 col-xlg-3">
                <div class="card card-hover">
                    <div class="box bg-danger text-center">
                        <h1 class="font-light text-white">
                            <i class="mdi mdi-border-outside"></i>
                        </h1>
                        <h6 class="text-white">รายการขายเดือนนี้</h6>
                        <span class="text-white"><?php echo e(number_format($listsale_count_month)); ?> รายการ</span>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-3 col-xlg-3">
                <div class="card card-hover">
                    <div class="box bg-info text-center">
                        <h1 class="font-light text-white">
                            <i class="mdi mdi-arrow-all"></i>
                        </h1>
                        <h6 class="text-white">รายการขายทั้งหมด</h6>
                        <span class="text-white"><?php echo e(number_format($listsale_count)); ?> รายการ</span>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <div class="col-md-6 col-lg-4 col-xlg-3">
                <div class="card card-hover">
                    <div class="box bg-danger text-center">
                        <h1 class="font-light text-white">
                            <i class="mdi mdi-receipt"></i>
                        </h1>
                        <h6 class="text-white">ยอดขายวันนี้</h6>
                        <span class="text-white"><?php echo e(number_format($totalProductPriceDay, 2)); ?> บาท</span>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-4 col-xlg-3">
                <div class="card card-hover">
                    <div class="box bg-info text-center">
                        <h1 class="font-light text-white">
                            <i class="mdi mdi-relative-scale"></i>
                        </h1>
                        <h6 class="text-white">ยอดขายเดือนนี้</h6>
                        <span class="text-white"><?php echo e(number_format($totalProductPriceMonth, 2)); ?> บาท</span>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-4 col-xlg-3">
                <div class="card card-hover">
                    <div class="box bg-cyan text-center">
                        <h1 class="font-light text-white">
                            <i class="mdi mdi-pencil"></i>
                        </h1>
                        <h6 class="text-white">ยอดขายทั้งหมด</h6>
                        <span class="text-white"><?php echo e(number_format($totalProductPriceAll, 2)); ?> บาท</span>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <!-- ============================================================== -->
    <!-- Sales chart -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <!-- column -->
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-12">
                                    <h5>รายการขายวันนี้</h5>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table id="zero_config" class="table table-striped table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>รหัสการขาย </th>
                                                            <th>พนักงานขาย</th>
                                                            <th>วันที่ขาย</th>
                                                            <th></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            $i = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $listSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($listSale->order_code); ?></td>
                                                                <td><?php echo e($listSale->users->first_name); ?>

                                                                    <?php echo e($listSale->users->last_name); ?> </td>
                                                                <td><?php echo e(date_format($listSale->created_at, 'd/m/Y H:i')); ?> น.
                                                                </td>
                                                                <td><a href="<?php echo e(route('detial_history', $listSale->id)); ?>"
                                                                        class="btn btn-outline-info">รายละเอียด</a></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        
                        <!-- column -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Sales chart -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sale-course/resources/views/pages/home.blade.php ENDPATH**/ ?>