<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">
                    เพิ่มสินค้าใหม่</h1>
                <button type="button" class="btn-close" onclick="closeModal()" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form id="productForm" class="form-horizontal" method="post" action="<?php echo e(url('/products')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id_product" id="id_product">
                    <h4 class="card-title">รายละเอียดสินค้า</h4>
                    <div class="form-group row">
                        <label for="fname" class="col-sm-3 text-end control-label col-form-label">
                            ภาพสินค้า</label>
                        <div class="col-sm-9">
                            <div class="d-flex justify-content-center">
                                <img id="blah" src="#" alt="your image" width="90" height="70"
                                    class="rounded mb-2 d-none" />
                            </div>
                            <input v-on:change="handleFileChange" accept="image/*" name="image" type='file'
                                id="imgInp" class="form-control" />
                        </div>
                    </div>
                    {{ form }}
                    <div class="form-group row">
                        <label for="fname" class="col-sm-3 text-end control-label col-form-label">
                            ชื่อสินค้า</label>
                        <div class="col-sm-9">
                            <input type="text" v-model="form.product_name" class="form-control" id="product_name"
                                name="product_name" placeholder="โปรดระบุชื่อสินค้า" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="lname" class="col-sm-3 text-end control-label col-form-label">
                            หมวดหมู่สินค้า</label>
                        <div class="col-sm-9">
                            <select v-model="form.category" class="form-select" name="category" id="category"
                                onchange="findSubCategory(event)">
                                <option value="" disabled selected>เลือกหมวดหมู่</option>
                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>">
                                        <?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="lname" class="col-sm-3 text-end control-label col-form-label">
                            แบรนด์ / ยี่ห้อ</label>
                        <div class="col-sm-9">
                            <select v-model="form.sub_category" class="form-select" name="sub_category"
                                id="sub_category">
                                <option value="" disabled selected>เลือกประเภท</option>
                                <div id="result_list_sub_category"></div>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email1" class="col-sm-3 text-end control-label col-form-label">สินค้า SKU</label>
                        <div class="col-sm-9">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                    id="flexSwitchCheckChecked" :checked="checkSku" v-on:click="toggleCheck">
                                <label class="form-check-label" for="flexSwitchCheckChecked">เปิดใช้งาน</label>
                            </div>
                            {{ features }}
                            <div v-if="checkSku">
                                <div class="card" v-for="(feature,index) in features" :key="index">
                                    <div class="card-body  rounded">
                                        <h5 class="card-title">คุณสมบัติ 1</h5>
                                        <select name="" id="" class="form-select mb-2">
                                            <option value="" selected disabled>เลือกคุณสมบัติ</option>
                                            <option value="color">สี</option>
                                        </select>
                                        <label for="">ตัวเลือก</label>
                                        <div class="form-group" v-for="(feature,index) in features[index]"
                                            :key="index">
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" v-model="feature.text">
                                                <span class="input-group-text text-white bg-danger" id="basic-addon2"
                                                    v-on:click="removeInput(index)"><i
                                                        class="fa-solid fa-trash"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-outline-primary w-100"
                                        v-on:click="addFeature(index)">+
                                        เพิ่มตัวเลือก</button>
                                </div>


                                <button type="button"
                                    :class="`btn btn-info w-100 my-3 ${countFeatures >=2 ? 'd-none' : 'd-block'}`"
                                    v-on:click="addFeatureMain">+
                                    เพิ่มคุณสมบัติ</button>

                                <table class="table table-bordered text-center">
                                    <thead>
                                        <tr>
                                            <th>คุณสมบัติ</th>
                                            <th>ราคา</th>
                                            <th>จำนวน</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-if="combinations != ''"
                                            v-for="(combination, comboIndex) in combinations" :key="comboIndex">
                                            <td>
                                                <div>
                                                    <p>{{ combination }}</p>

                                                </div>

                                            </td>
                                            <td width="27%">
                                                <input type="number" v-model="inputGroupPrice[comboIndex]"
                                                    class="form-control">

                                            </td>
                                            <td width="27%">
                                                <input type="number" v-model="inputGroupCount[comboIndex]"
                                                    class="form-control">

                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email1"
                            class="col-sm-3 text-end control-label col-form-label">วันหมดอายุ</label>
                        <div class="col-sm-9">
                            <input v-model="form.Expiry_Date" type="date" class="form-control" id="Expiry_Date"
                                name="Expiry_Date" placeholder="วันหมดอายุ" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email1"
                            class="col-sm-3 text-end control-label col-form-label">รหัสสินค้า*</label>
                        <div class="col-sm-9">
                            <input v-model="form.code" type="text" class="form-control" id="code"
                                name="code" placeholder="โปรดระบุรหัสสินค้า" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cono1"
                            class="col-sm-3 text-end control-label col-form-label">คลังสินค้า</label>
                        <div class="col-sm-9">
                            <input v-model="form.stock" type="text" class="form-control" id="stock"
                                name="stock" placeholder="โปรดระบุจำนวนสินค้า" />
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cono1" class="col-sm-3 text-end control-label col-form-label">น้ำหนัก</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">กก</span>
                                </div>
                                <input v-model="form.weight" type="text" name="weight" id="weight"
                                    class="form-control" placeholder="น้ำหนัก" aria-label="Username"
                                    aria-describedby="basic-addon1" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cono1"
                            class="col-sm-3 text-end control-label col-form-label">ต้นทุนราคาสินค้า</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">฿</span>
                                </div>
                                <input v-model="form.product_cost" type="text" name="product_cost"
                                    id="product_cost" class="form-control" placeholder="โปรดระบุราคาต้นทุน" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cono1"
                            class="col-sm-3 text-end control-label col-form-label">ราคาขายสินค้า</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">฿</span>
                                </div>
                                <input v-model="form.product_price" type="text" name="product_price"
                                    id="product_price" class="form-control" placeholder="โปรดระบุราคาขาย"
                                    aria-label="Username" aria-describedby="basic-addon1" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cono1"
                            class="col-sm-3 text-end control-label col-form-label">รายละเอียดสินค้า</label>
                        <div class="col-sm-9">
                            <textarea v-model="form.description" class="form-control" name="description" id="description"></textarea>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">ยกเลิก</button>
                <button type="button" v-on:click="submitForm" class="btn btn-primary"
                    id="submit_btn">บันทึก</button>
            </div>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    imgInp.onchange = evt => {
        $('#blah').removeClass('d-none')
        const [file] = imgInp.files
        if (file) {
            blah.src = URL.createObjectURL(file)
        }
    }

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });


    function closeModal() {
        $('#id_product').val('');
        $('#blah').attr('src', '')
        $('#sub_category').html('<option value="" disabled selected>เลือกประเภท</option>')
        $('#staticBackdrop').modal('hide')
        document.getElementById('productForm').reset();
        $(".error-message").remove();
    }

    function findSubCategory(e) {

        $.ajax({
            url: '/subcategory/' + e.target.value,
            type: 'get',
            success: function(response) {
                let show_list = ''
                response.forEach(element => {
                    show_list +=
                        `<option value="${element.id}">${element.sub_category_name}</option>`
                });

                $('#sub_category').html(show_list)
            },
            error: function(xhr) {
                console.log(xhr);
            }
        });
    }
    $(document).ready(function() {
        // $("#productForm").submit(function(event) {
        //     event.preventDefault();

        //     var formData = new FormData(this);
        //     var imageInput = $('input[name="image"]')[0];
        //     console.log(imageInput.files[0]);

        //     formData.append('image', imageInput.files[0]);

        //     $.ajax({
        //         url: $(this).attr("action"),
        //         type: $(this).attr("method"),
        //         data: formData,
        //         contentType: false,
        //         processData: false,
        //         success: function(response) {
        //             $('#submit_btn').attr('disabled', '')
        //             const Toast = Swal.mixin({
        //                 toast: true,
        //                 position: 'top-end',
        //                 showConfirmButton: false,
        //                 timer: 3000,
        //                 timerProgressBar: true,
        //                 didOpen: (toast) => {
        //                     toast.addEventListener('mouseenter', Swal
        //                         .stopTimer);
        //                     toast.addEventListener('mouseleave', Swal
        //                         .resumeTimer);
        //                 }
        //             });

        //             Toast.fire({
        //                 icon: 'success',
        //                 title: "บันทึกสินค้าสำเร็จ"
        //             });

        //             setTimeout(() => {
        //                 location.reload()
        //             }, 1200);

        //         },
        //         error: function(xhr) {

        //             if (xhr.status === 422) {
        //                 var errors = xhr.responseJSON.errors;

        //                 $(".error-message").remove();

        //                 $.each(errors, function(field, errorMessages) {
        //                     var errorHtml =
        //                         '<div class="error-message text-danger">' +
        //                         errorMessages.join(', ') + '</div>';
        //                     $("#" + field).closest(".col-sm-9").append(errorHtml);
        //                 });
        //             } else {
        //                 console.error("Form submission failed");
        //             }
        //         }
        //     });
        // });


    });


    function EditProduct(id) {
        $('#blah').removeClass('d-none')
        $('#id_product').val(id);
        $('#submit_btn').text('อัพเดต')
        $.ajax({
            url: '/products/' + id + '/edit',
            type: 'get',
            success: function(response) {
                $('#blah').attr('src', 'storage/uploads/' + response.product_img)
                $('#product_name').val(response.product_name)
                $('#product_price').val(response.product_price)
                $('#Expiry_Date').val(response.Expiry_Date)
                $('#code').val(response.code)
                $('#stock').val(response.stock)
                $('#description').val(response.description)
                $('#weight').val(response.weight)
                $('#product_cost').val(response.product_cost)
                $('#weight').val(response.weight)
                $('#category').val(response.category ? response.category.id : '')
                $('#sub_category').val(response.subcategory ? response.subcategory.id : '')
                $('#staticBackdrop').modal('show')
            },
            error: function(xhr) {
                console.log(xhr.status);
            }
        })
    }

    function openModal() {
        $('#submit_btn').text('บันทึก');
        $('#blah').addClass('d-none')
        $('#staticBackdrop').modal('show')
    }

    var app = new Vue({
        el: '#product',
        data() {
            return {
                message: "hello",
                checkSku: false,
                features: {
                    0: [{
                        text: "",
                        value: "d"
                    }]
                },
                inputGroupPrice: [""],
                inputGroupCount: [""],
                form: {
                    imageInput: "",
                    product_name: "",
                    category: "",
                    sub_category: "",
                    Expiry_Date: "",
                    code: "",
                    stock: "",
                    weight: "",
                    product_cost: "",
                    product_price: "",
                    description: "",
                    feature1: "",
                    feature2: "",

                },
                formData: new FormData(),

            };
        },

        methods: {
            EditProduct(id) {
                $('#blah').removeClass('d-none')
                $('#id_product').val(id);
                $('#submit_btn').text('อัพเดต')

                // $.ajax({
                //     url: '/products/' + id + '/edit',
                //     type: 'get',
                //     success: function(response) {
                //         $('#blah').attr('src', 'storage/uploads/' + response.product_img)
                //         $('#product_name').val(response.product_name)
                //         $('#product_price').val(response.product_price)
                //         $('#Expiry_Date').val(response.Expiry_Date)
                //         $('#code').val(response.code)
                //         $('#stock').val(response.stock)
                //         $('#description').val(response.description)
                //         $('#weight').val(response.weight)
                //         $('#product_cost').val(response.product_cost)
                //         $('#weight').val(response.weight)
                //         $('#category').val(response.category ? response.category.id : '')
                //         $('#sub_category').val(response.subcategory ? response.subcategory.id : '')
                //         $('#staticBackdrop').modal('show')
                //     },
                //     error: function(xhr) {
                //         console.log(xhr.status);
                //     }
                // })

                axios.get(`/products/${id}/edit`).then(response =>{
                    $('#blah').attr('src', 'storage/uploads/' + response.product_img)
                        $('#product_name').val(response.product_name)
                        $('#product_price').val(response.product_price)
                        $('#Expiry_Date').val(response.Expiry_Date)
                        $('#code').val(response.code)
                        $('#stock').val(response.stock)
                        $('#description').val(response.description)
                        $('#weight').val(response.weight)
                        $('#product_cost').val(response.product_cost)
                        $('#weight').val(response.weight)
                        $('#category').val(response.category ? response.category.id : '')
                        $('#sub_category').val(response.subcategory ? response.subcategory.id : '')
                        $('#staticBackdrop').modal('show')
                }).catch(e=>{
                    console.log(e);
                })
            },
            toggleCheck() {
                this.checkSku = !this.checkSku
            },
            addFeature(index) {
                this.inputGroupPrice.push("")
                this.inputGroupCount.push("")
                this.features[index].push({
                    text: "",
                    value: ""
                });
            },
            removeInput(index) {
                this.features.splice(index);
            },
            addFeatureMain() {
                this.inputGroupPrice.push("")
                this.inputGroupCount.push("")
                const newIndex = Object.keys(this.features).length; // Calculate the next index
                this.$set(this.features, +newIndex, [{
                    text: "",
                    value: ""
                }]);
            },
            handleFileChange(event) {
                this.form.imageInput = event.target.files[0];
            },
            submitForm() {
                const features1 = this.features["0"].map((color) => color.text);
                const features2 = this.features["1"] ? this.features["1"].map((letter) => letter.text) : [];
                const inputPrice = this.inputGroupPrice.map((data) => data);
                const inputCount = this.inputGroupCount.map((data) => data);

                const combinations = [];

                features1.forEach((feature1, colorIndex) => {
                    if (features2.length > 0) {
                        features2.forEach((feature2, sizeIndex) => {
                            const obj = {
                                feature1,
                                feature2,
                                price: inputPrice[colorIndex * features2.length +
                                    sizeIndex],
                                count: inputCount[colorIndex * features2.length +
                                    sizeIndex],
                            };
                            combinations.push(obj);
                        });
                    } else {
                        const obj = {
                            feature1,
                            price: inputPrice[colorIndex],
                            count: inputCount[colorIndex],
                        };
                        combinations.push(obj);
                    }
                });

                this.formData.append('image', this.form.imageInput);
                this.formData.append('product_name', this.form.product_name);
                this.formData.append('category', this.form.category);
                this.formData.append('sub_category', this.form.sub_category);
                this.formData.append('Expiry_Date', this.form.Expiry_Date);
                this.formData.append('code', this.form.code);
                this.formData.append('stock', this.form.stock);
                this.formData.append('weight', this.form.weight);
                this.formData.append('product_cost', this.form.product_cost);
                this.formData.append('product_price', this.form.product_price);
                this.formData.append('description', this.form.description);
                if (this.checkSku) {
                    this.formData.append('combinations', JSON.stringify(combinations))
                } else {
                    this.formData.append('combinations', null)
                }

                axios({
                        method: 'post',
                        url: 'products',
                        data: this.formData,
                        headers: {
                            'Content-Type': 'multipart/form-data',
                        }
                    })
                    .then(response => {
                        // Handle success
                        console.log(response.data);

                        // Show success message (you can use a notification library)
                        // this.showSuccessMessage('บันทึกสินค้าสำเร็จ');

                        // Reset form and image input
                        this.formData = new FormData();
                        // this.imageInput = null;
                    })
                    .catch(error => {
                        if (error.response && error.response.status === 422) {
                            // Validation error response
                            const errors = error.response.data.errors;

                            // Handle validation errors
                            Object.keys(errors).forEach(field => {
                                const errorMessages = errors[field];
                                const errorHtml = '<div class="error-message text-danger">' +
                                    errorMessages.join(', ') + '</div>';
                                $("#" + field).closest(".col-sm-9").append(errorHtml);
                            });
                        } else {
                            console.error("Form submission failed");
                        }
                    })


            }

        },
        computed: {
            countFeatures() {
                return Object.keys(this.features).length;
            },
            combinations() {
                const colors = this.features["0"].map((color) => color.text);
                const letters = this.features["1"] ? this.features["1"].map((letter) => letter.text) : [];
                const result = [];
                for (const color of colors) {
                    if (letters.length !== 0) {
                        for (const letter of letters) {
                            result.push(`${color}/${letter}`);
                        }
                    } else {
                        result.push(`${color}`);
                    }
                }
                return result;
            },
        },
        mounted() {
            console.log(Object.keys(this.features).length);
        },
    })
</script>
<?php /**PATH /Applications/MAMP/htdocs/pos 2/resources/views/components/modalProduct.blade.php ENDPATH**/ ?>